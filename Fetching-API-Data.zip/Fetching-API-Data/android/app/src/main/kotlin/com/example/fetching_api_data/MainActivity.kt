package com.example.fetching_api_data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
